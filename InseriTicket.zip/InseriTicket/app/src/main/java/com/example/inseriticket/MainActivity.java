package com.example.inseriticket;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CALL_PERMISSION = 1;
    private EditText inputTicket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputTicket = findViewById(R.id.input_ticket);
        Button callButton = findViewById(R.id.btn_ligar);
        Button atvWeb = findViewById(R.id.btn_atvweb);
        Button gdrive = findViewById(R.id.btn_gdrive);
        Button consultTicket = findViewById(R.id.btn_consulTicket);

        callButton.setOnClickListener(v -> {
            String ticket = inputTicket.getText().toString().trim();
            if (ticket.isEmpty()) {
                Toast.makeText(this, "Digite o número do ticket!", Toast.LENGTH_SHORT).show();
                return;
            }
            fazerLigacao(ticket);
        });


        atvWeb.setOnClickListener(v -> {
            String url = "http://200.251.113.76/rpedro/login/#/";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            Toast.makeText(this, "Abrindo AtvWEB!", Toast.LENGTH_LONG).show();
            startActivity(intent);

            // Verifica se existe app que pode abrir
//            if (intent.resolveActivity(getPackageManager()) != null) {
//                startActivity(intent);
//            }
        });

        gdrive.setOnClickListener(v -> {
            String url = "https://drive.google.com/drive/folders/0ByWXKjBlkrATLVgtRHpQcmlpQkE?resourcekey=0-NeLn4_z4V87vkgoyFT4iDQ&usp=drive_link";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            Toast.makeText(this, "Abrindo GDrive ROTEADORES!", Toast.LENGTH_LONG).show();
            startActivity(intent);

            // Verifica se existe app que pode abrir
//            if (intent.resolveActivity(getPackageManager()) != null) {
//                startActivity(intent);
//            }
        });
        consultTicket.setOnClickListener(v -> {
            String url = "https://modos.embratel.net.br/uraweb";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            Toast.makeText(this, "Abrindo CONSULTA TICKETS!", Toast.LENGTH_LONG).show();
            startActivity(intent);

            // Verifica se existe app que pode abrir
//            if (intent.resolveActivity(getPackageManager()) != null) {
//                startActivity(intent);
//            }
        });
    }




    private void fazerLigacao(String ticket) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL_PERMISSION);
        } else {
            iniciarChamada(ticket);
        }
    }

    private void iniciarChamada(String ticket) {
        String numero = "tel:08007218004,,1,," + ticket + ",,,,1";
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse(numero));
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            String ticket = inputTicket.getText().toString().trim();
            iniciarChamada(ticket);
        }
    }
}

